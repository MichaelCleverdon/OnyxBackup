#ifndef LINKAGE_H
#define LINKAGE_H

#ifdef __cplusplus
#define LINKAGE "C"
#else
#define LINKAGE
#endif

#endif
